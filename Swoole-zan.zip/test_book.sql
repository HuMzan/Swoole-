/*
 Navicat Premium Data Transfer

 Source Server         : 192.168.0.171
 Source Server Type    : MySQL
 Source Server Version : 50556
 Source Host           : 192.168.0.171:3306
 Source Schema         : test_book

 Target Server Type    : MySQL
 Target Server Version : 50556
 File Encoding         : 65001

 Date: 10/11/2018 19:26:02
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for nl_class
-- ----------------------------
DROP TABLE IF EXISTS `nl_class`;
CREATE TABLE `nl_class`  (
  `cid` bigint(11) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '分类名',
  `sort` int(5) NOT NULL DEFAULT 0 COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`cid`) USING BTREE,
  UNIQUE INDEX `IndexName`(`class_name`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter`;
CREATE TABLE `nl_novel_chapter`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter0
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter0`;
CREATE TABLE `nl_novel_chapter0`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter1
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter1`;
CREATE TABLE `nl_novel_chapter1`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter10
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter10`;
CREATE TABLE `nl_novel_chapter10`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter100
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter100`;
CREATE TABLE `nl_novel_chapter100`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter101
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter101`;
CREATE TABLE `nl_novel_chapter101`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter102
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter102`;
CREATE TABLE `nl_novel_chapter102`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter103
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter103`;
CREATE TABLE `nl_novel_chapter103`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter104
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter104`;
CREATE TABLE `nl_novel_chapter104`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter105
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter105`;
CREATE TABLE `nl_novel_chapter105`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter106
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter106`;
CREATE TABLE `nl_novel_chapter106`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter107
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter107`;
CREATE TABLE `nl_novel_chapter107`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter108
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter108`;
CREATE TABLE `nl_novel_chapter108`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter109
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter109`;
CREATE TABLE `nl_novel_chapter109`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter11
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter11`;
CREATE TABLE `nl_novel_chapter11`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter110
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter110`;
CREATE TABLE `nl_novel_chapter110`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter111
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter111`;
CREATE TABLE `nl_novel_chapter111`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter112
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter112`;
CREATE TABLE `nl_novel_chapter112`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter113
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter113`;
CREATE TABLE `nl_novel_chapter113`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter114
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter114`;
CREATE TABLE `nl_novel_chapter114`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter115
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter115`;
CREATE TABLE `nl_novel_chapter115`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter116
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter116`;
CREATE TABLE `nl_novel_chapter116`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter117
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter117`;
CREATE TABLE `nl_novel_chapter117`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter118
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter118`;
CREATE TABLE `nl_novel_chapter118`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter119
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter119`;
CREATE TABLE `nl_novel_chapter119`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter12
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter12`;
CREATE TABLE `nl_novel_chapter12`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter120
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter120`;
CREATE TABLE `nl_novel_chapter120`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter121
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter121`;
CREATE TABLE `nl_novel_chapter121`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter122
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter122`;
CREATE TABLE `nl_novel_chapter122`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter123
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter123`;
CREATE TABLE `nl_novel_chapter123`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter124
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter124`;
CREATE TABLE `nl_novel_chapter124`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter125
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter125`;
CREATE TABLE `nl_novel_chapter125`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter126
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter126`;
CREATE TABLE `nl_novel_chapter126`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter127
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter127`;
CREATE TABLE `nl_novel_chapter127`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter128
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter128`;
CREATE TABLE `nl_novel_chapter128`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter129
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter129`;
CREATE TABLE `nl_novel_chapter129`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter13
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter13`;
CREATE TABLE `nl_novel_chapter13`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter130
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter130`;
CREATE TABLE `nl_novel_chapter130`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter131
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter131`;
CREATE TABLE `nl_novel_chapter131`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter132
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter132`;
CREATE TABLE `nl_novel_chapter132`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter133
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter133`;
CREATE TABLE `nl_novel_chapter133`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter134
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter134`;
CREATE TABLE `nl_novel_chapter134`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter135
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter135`;
CREATE TABLE `nl_novel_chapter135`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter136
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter136`;
CREATE TABLE `nl_novel_chapter136`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter137
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter137`;
CREATE TABLE `nl_novel_chapter137`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter138
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter138`;
CREATE TABLE `nl_novel_chapter138`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter139
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter139`;
CREATE TABLE `nl_novel_chapter139`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter14
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter14`;
CREATE TABLE `nl_novel_chapter14`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter140
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter140`;
CREATE TABLE `nl_novel_chapter140`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter141
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter141`;
CREATE TABLE `nl_novel_chapter141`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter142
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter142`;
CREATE TABLE `nl_novel_chapter142`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter143
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter143`;
CREATE TABLE `nl_novel_chapter143`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter144
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter144`;
CREATE TABLE `nl_novel_chapter144`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter145
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter145`;
CREATE TABLE `nl_novel_chapter145`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter146
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter146`;
CREATE TABLE `nl_novel_chapter146`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter147
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter147`;
CREATE TABLE `nl_novel_chapter147`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter148
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter148`;
CREATE TABLE `nl_novel_chapter148`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter149
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter149`;
CREATE TABLE `nl_novel_chapter149`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter15
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter15`;
CREATE TABLE `nl_novel_chapter15`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter150
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter150`;
CREATE TABLE `nl_novel_chapter150`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter151
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter151`;
CREATE TABLE `nl_novel_chapter151`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter152
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter152`;
CREATE TABLE `nl_novel_chapter152`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter153
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter153`;
CREATE TABLE `nl_novel_chapter153`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter154
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter154`;
CREATE TABLE `nl_novel_chapter154`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter155
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter155`;
CREATE TABLE `nl_novel_chapter155`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter156
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter156`;
CREATE TABLE `nl_novel_chapter156`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter157
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter157`;
CREATE TABLE `nl_novel_chapter157`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter158
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter158`;
CREATE TABLE `nl_novel_chapter158`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter159
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter159`;
CREATE TABLE `nl_novel_chapter159`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter16
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter16`;
CREATE TABLE `nl_novel_chapter16`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter160
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter160`;
CREATE TABLE `nl_novel_chapter160`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter161
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter161`;
CREATE TABLE `nl_novel_chapter161`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter162
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter162`;
CREATE TABLE `nl_novel_chapter162`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter163
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter163`;
CREATE TABLE `nl_novel_chapter163`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter164
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter164`;
CREATE TABLE `nl_novel_chapter164`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter165
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter165`;
CREATE TABLE `nl_novel_chapter165`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter166
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter166`;
CREATE TABLE `nl_novel_chapter166`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter167
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter167`;
CREATE TABLE `nl_novel_chapter167`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter168
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter168`;
CREATE TABLE `nl_novel_chapter168`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter169
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter169`;
CREATE TABLE `nl_novel_chapter169`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter17
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter17`;
CREATE TABLE `nl_novel_chapter17`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter170
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter170`;
CREATE TABLE `nl_novel_chapter170`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter171
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter171`;
CREATE TABLE `nl_novel_chapter171`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter172
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter172`;
CREATE TABLE `nl_novel_chapter172`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter173
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter173`;
CREATE TABLE `nl_novel_chapter173`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter174
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter174`;
CREATE TABLE `nl_novel_chapter174`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter175
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter175`;
CREATE TABLE `nl_novel_chapter175`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter176
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter176`;
CREATE TABLE `nl_novel_chapter176`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter177
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter177`;
CREATE TABLE `nl_novel_chapter177`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter178
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter178`;
CREATE TABLE `nl_novel_chapter178`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter179
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter179`;
CREATE TABLE `nl_novel_chapter179`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter18
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter18`;
CREATE TABLE `nl_novel_chapter18`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter180
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter180`;
CREATE TABLE `nl_novel_chapter180`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter181
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter181`;
CREATE TABLE `nl_novel_chapter181`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter182
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter182`;
CREATE TABLE `nl_novel_chapter182`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter183
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter183`;
CREATE TABLE `nl_novel_chapter183`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter184
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter184`;
CREATE TABLE `nl_novel_chapter184`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter185
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter185`;
CREATE TABLE `nl_novel_chapter185`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter186
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter186`;
CREATE TABLE `nl_novel_chapter186`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter187
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter187`;
CREATE TABLE `nl_novel_chapter187`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter188
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter188`;
CREATE TABLE `nl_novel_chapter188`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter189
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter189`;
CREATE TABLE `nl_novel_chapter189`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter19
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter19`;
CREATE TABLE `nl_novel_chapter19`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter190
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter190`;
CREATE TABLE `nl_novel_chapter190`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter191
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter191`;
CREATE TABLE `nl_novel_chapter191`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter192
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter192`;
CREATE TABLE `nl_novel_chapter192`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter193
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter193`;
CREATE TABLE `nl_novel_chapter193`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter194
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter194`;
CREATE TABLE `nl_novel_chapter194`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter195
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter195`;
CREATE TABLE `nl_novel_chapter195`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter196
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter196`;
CREATE TABLE `nl_novel_chapter196`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter197
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter197`;
CREATE TABLE `nl_novel_chapter197`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter198
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter198`;
CREATE TABLE `nl_novel_chapter198`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter199
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter199`;
CREATE TABLE `nl_novel_chapter199`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter2
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter2`;
CREATE TABLE `nl_novel_chapter2`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter20
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter20`;
CREATE TABLE `nl_novel_chapter20`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter200
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter200`;
CREATE TABLE `nl_novel_chapter200`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter201
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter201`;
CREATE TABLE `nl_novel_chapter201`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter202
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter202`;
CREATE TABLE `nl_novel_chapter202`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter203
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter203`;
CREATE TABLE `nl_novel_chapter203`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter204
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter204`;
CREATE TABLE `nl_novel_chapter204`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter205
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter205`;
CREATE TABLE `nl_novel_chapter205`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter206
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter206`;
CREATE TABLE `nl_novel_chapter206`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter207
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter207`;
CREATE TABLE `nl_novel_chapter207`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter208
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter208`;
CREATE TABLE `nl_novel_chapter208`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter209
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter209`;
CREATE TABLE `nl_novel_chapter209`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter21
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter21`;
CREATE TABLE `nl_novel_chapter21`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter210
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter210`;
CREATE TABLE `nl_novel_chapter210`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter211
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter211`;
CREATE TABLE `nl_novel_chapter211`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter212
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter212`;
CREATE TABLE `nl_novel_chapter212`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter213
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter213`;
CREATE TABLE `nl_novel_chapter213`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter214
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter214`;
CREATE TABLE `nl_novel_chapter214`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter215
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter215`;
CREATE TABLE `nl_novel_chapter215`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter216
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter216`;
CREATE TABLE `nl_novel_chapter216`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter217
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter217`;
CREATE TABLE `nl_novel_chapter217`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter218
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter218`;
CREATE TABLE `nl_novel_chapter218`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter219
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter219`;
CREATE TABLE `nl_novel_chapter219`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter22
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter22`;
CREATE TABLE `nl_novel_chapter22`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter220
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter220`;
CREATE TABLE `nl_novel_chapter220`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter221
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter221`;
CREATE TABLE `nl_novel_chapter221`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter222
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter222`;
CREATE TABLE `nl_novel_chapter222`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter223
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter223`;
CREATE TABLE `nl_novel_chapter223`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter224
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter224`;
CREATE TABLE `nl_novel_chapter224`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter225
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter225`;
CREATE TABLE `nl_novel_chapter225`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter226
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter226`;
CREATE TABLE `nl_novel_chapter226`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter227
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter227`;
CREATE TABLE `nl_novel_chapter227`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter228
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter228`;
CREATE TABLE `nl_novel_chapter228`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter229
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter229`;
CREATE TABLE `nl_novel_chapter229`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter23
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter23`;
CREATE TABLE `nl_novel_chapter23`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter230
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter230`;
CREATE TABLE `nl_novel_chapter230`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter231
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter231`;
CREATE TABLE `nl_novel_chapter231`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter232
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter232`;
CREATE TABLE `nl_novel_chapter232`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter233
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter233`;
CREATE TABLE `nl_novel_chapter233`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter234
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter234`;
CREATE TABLE `nl_novel_chapter234`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter235
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter235`;
CREATE TABLE `nl_novel_chapter235`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter236
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter236`;
CREATE TABLE `nl_novel_chapter236`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter237
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter237`;
CREATE TABLE `nl_novel_chapter237`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter238
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter238`;
CREATE TABLE `nl_novel_chapter238`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter239
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter239`;
CREATE TABLE `nl_novel_chapter239`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter24
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter24`;
CREATE TABLE `nl_novel_chapter24`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter240
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter240`;
CREATE TABLE `nl_novel_chapter240`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter241
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter241`;
CREATE TABLE `nl_novel_chapter241`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter242
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter242`;
CREATE TABLE `nl_novel_chapter242`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter243
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter243`;
CREATE TABLE `nl_novel_chapter243`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter244
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter244`;
CREATE TABLE `nl_novel_chapter244`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter245
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter245`;
CREATE TABLE `nl_novel_chapter245`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter246
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter246`;
CREATE TABLE `nl_novel_chapter246`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter247
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter247`;
CREATE TABLE `nl_novel_chapter247`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter248
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter248`;
CREATE TABLE `nl_novel_chapter248`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter249
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter249`;
CREATE TABLE `nl_novel_chapter249`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter25
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter25`;
CREATE TABLE `nl_novel_chapter25`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter250
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter250`;
CREATE TABLE `nl_novel_chapter250`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter251
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter251`;
CREATE TABLE `nl_novel_chapter251`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter252
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter252`;
CREATE TABLE `nl_novel_chapter252`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter253
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter253`;
CREATE TABLE `nl_novel_chapter253`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter254
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter254`;
CREATE TABLE `nl_novel_chapter254`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter255
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter255`;
CREATE TABLE `nl_novel_chapter255`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter256
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter256`;
CREATE TABLE `nl_novel_chapter256`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter257
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter257`;
CREATE TABLE `nl_novel_chapter257`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter258
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter258`;
CREATE TABLE `nl_novel_chapter258`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter259
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter259`;
CREATE TABLE `nl_novel_chapter259`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter26
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter26`;
CREATE TABLE `nl_novel_chapter26`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter260
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter260`;
CREATE TABLE `nl_novel_chapter260`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter261
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter261`;
CREATE TABLE `nl_novel_chapter261`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter262
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter262`;
CREATE TABLE `nl_novel_chapter262`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter263
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter263`;
CREATE TABLE `nl_novel_chapter263`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter264
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter264`;
CREATE TABLE `nl_novel_chapter264`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter265
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter265`;
CREATE TABLE `nl_novel_chapter265`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter266
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter266`;
CREATE TABLE `nl_novel_chapter266`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter267
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter267`;
CREATE TABLE `nl_novel_chapter267`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter268
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter268`;
CREATE TABLE `nl_novel_chapter268`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter269
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter269`;
CREATE TABLE `nl_novel_chapter269`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter27
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter27`;
CREATE TABLE `nl_novel_chapter27`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter270
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter270`;
CREATE TABLE `nl_novel_chapter270`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter271
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter271`;
CREATE TABLE `nl_novel_chapter271`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter272
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter272`;
CREATE TABLE `nl_novel_chapter272`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter273
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter273`;
CREATE TABLE `nl_novel_chapter273`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter274
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter274`;
CREATE TABLE `nl_novel_chapter274`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter275
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter275`;
CREATE TABLE `nl_novel_chapter275`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter276
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter276`;
CREATE TABLE `nl_novel_chapter276`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter277
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter277`;
CREATE TABLE `nl_novel_chapter277`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter278
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter278`;
CREATE TABLE `nl_novel_chapter278`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter279
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter279`;
CREATE TABLE `nl_novel_chapter279`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter28
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter28`;
CREATE TABLE `nl_novel_chapter28`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter280
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter280`;
CREATE TABLE `nl_novel_chapter280`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter281
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter281`;
CREATE TABLE `nl_novel_chapter281`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter282
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter282`;
CREATE TABLE `nl_novel_chapter282`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter283
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter283`;
CREATE TABLE `nl_novel_chapter283`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter284
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter284`;
CREATE TABLE `nl_novel_chapter284`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter285
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter285`;
CREATE TABLE `nl_novel_chapter285`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter286
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter286`;
CREATE TABLE `nl_novel_chapter286`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter287
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter287`;
CREATE TABLE `nl_novel_chapter287`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter288
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter288`;
CREATE TABLE `nl_novel_chapter288`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter289
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter289`;
CREATE TABLE `nl_novel_chapter289`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter29
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter29`;
CREATE TABLE `nl_novel_chapter29`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter290
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter290`;
CREATE TABLE `nl_novel_chapter290`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter291
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter291`;
CREATE TABLE `nl_novel_chapter291`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter292
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter292`;
CREATE TABLE `nl_novel_chapter292`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter293
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter293`;
CREATE TABLE `nl_novel_chapter293`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter294
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter294`;
CREATE TABLE `nl_novel_chapter294`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter295
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter295`;
CREATE TABLE `nl_novel_chapter295`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter296
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter296`;
CREATE TABLE `nl_novel_chapter296`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter297
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter297`;
CREATE TABLE `nl_novel_chapter297`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter298
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter298`;
CREATE TABLE `nl_novel_chapter298`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter299
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter299`;
CREATE TABLE `nl_novel_chapter299`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter3
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter3`;
CREATE TABLE `nl_novel_chapter3`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter30
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter30`;
CREATE TABLE `nl_novel_chapter30`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter300
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter300`;
CREATE TABLE `nl_novel_chapter300`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter31
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter31`;
CREATE TABLE `nl_novel_chapter31`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter32
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter32`;
CREATE TABLE `nl_novel_chapter32`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter33
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter33`;
CREATE TABLE `nl_novel_chapter33`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter34
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter34`;
CREATE TABLE `nl_novel_chapter34`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter35
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter35`;
CREATE TABLE `nl_novel_chapter35`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter36
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter36`;
CREATE TABLE `nl_novel_chapter36`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter37
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter37`;
CREATE TABLE `nl_novel_chapter37`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter38
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter38`;
CREATE TABLE `nl_novel_chapter38`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter39
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter39`;
CREATE TABLE `nl_novel_chapter39`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter4
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter4`;
CREATE TABLE `nl_novel_chapter4`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter40
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter40`;
CREATE TABLE `nl_novel_chapter40`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter41
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter41`;
CREATE TABLE `nl_novel_chapter41`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter42
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter42`;
CREATE TABLE `nl_novel_chapter42`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter43
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter43`;
CREATE TABLE `nl_novel_chapter43`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter44
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter44`;
CREATE TABLE `nl_novel_chapter44`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter45
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter45`;
CREATE TABLE `nl_novel_chapter45`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter46
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter46`;
CREATE TABLE `nl_novel_chapter46`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter47
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter47`;
CREATE TABLE `nl_novel_chapter47`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter48
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter48`;
CREATE TABLE `nl_novel_chapter48`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter49
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter49`;
CREATE TABLE `nl_novel_chapter49`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter5
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter5`;
CREATE TABLE `nl_novel_chapter5`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter50
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter50`;
CREATE TABLE `nl_novel_chapter50`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter51
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter51`;
CREATE TABLE `nl_novel_chapter51`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter52
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter52`;
CREATE TABLE `nl_novel_chapter52`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter53
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter53`;
CREATE TABLE `nl_novel_chapter53`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter54
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter54`;
CREATE TABLE `nl_novel_chapter54`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter55
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter55`;
CREATE TABLE `nl_novel_chapter55`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter56
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter56`;
CREATE TABLE `nl_novel_chapter56`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter57
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter57`;
CREATE TABLE `nl_novel_chapter57`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter58
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter58`;
CREATE TABLE `nl_novel_chapter58`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter59
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter59`;
CREATE TABLE `nl_novel_chapter59`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter6
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter6`;
CREATE TABLE `nl_novel_chapter6`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter60
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter60`;
CREATE TABLE `nl_novel_chapter60`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter61
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter61`;
CREATE TABLE `nl_novel_chapter61`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter62
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter62`;
CREATE TABLE `nl_novel_chapter62`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter63
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter63`;
CREATE TABLE `nl_novel_chapter63`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter64
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter64`;
CREATE TABLE `nl_novel_chapter64`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter65
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter65`;
CREATE TABLE `nl_novel_chapter65`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter66
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter66`;
CREATE TABLE `nl_novel_chapter66`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter67
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter67`;
CREATE TABLE `nl_novel_chapter67`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter68
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter68`;
CREATE TABLE `nl_novel_chapter68`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter69
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter69`;
CREATE TABLE `nl_novel_chapter69`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter7
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter7`;
CREATE TABLE `nl_novel_chapter7`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter70
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter70`;
CREATE TABLE `nl_novel_chapter70`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter71
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter71`;
CREATE TABLE `nl_novel_chapter71`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter72
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter72`;
CREATE TABLE `nl_novel_chapter72`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter73
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter73`;
CREATE TABLE `nl_novel_chapter73`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter74
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter74`;
CREATE TABLE `nl_novel_chapter74`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter75
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter75`;
CREATE TABLE `nl_novel_chapter75`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter76
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter76`;
CREATE TABLE `nl_novel_chapter76`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter77
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter77`;
CREATE TABLE `nl_novel_chapter77`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter78
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter78`;
CREATE TABLE `nl_novel_chapter78`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter79
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter79`;
CREATE TABLE `nl_novel_chapter79`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter8
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter8`;
CREATE TABLE `nl_novel_chapter8`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter80
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter80`;
CREATE TABLE `nl_novel_chapter80`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter81
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter81`;
CREATE TABLE `nl_novel_chapter81`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter82
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter82`;
CREATE TABLE `nl_novel_chapter82`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter83
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter83`;
CREATE TABLE `nl_novel_chapter83`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter84
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter84`;
CREATE TABLE `nl_novel_chapter84`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter85
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter85`;
CREATE TABLE `nl_novel_chapter85`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter86
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter86`;
CREATE TABLE `nl_novel_chapter86`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter87
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter87`;
CREATE TABLE `nl_novel_chapter87`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter88
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter88`;
CREATE TABLE `nl_novel_chapter88`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter89
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter89`;
CREATE TABLE `nl_novel_chapter89`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter9
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter9`;
CREATE TABLE `nl_novel_chapter9`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter90
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter90`;
CREATE TABLE `nl_novel_chapter90`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter91
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter91`;
CREATE TABLE `nl_novel_chapter91`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter92
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter92`;
CREATE TABLE `nl_novel_chapter92`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter93
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter93`;
CREATE TABLE `nl_novel_chapter93`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter94
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter94`;
CREATE TABLE `nl_novel_chapter94`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter95
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter95`;
CREATE TABLE `nl_novel_chapter95`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter96
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter96`;
CREATE TABLE `nl_novel_chapter96`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter97
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter97`;
CREATE TABLE `nl_novel_chapter97`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter98
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter98`;
CREATE TABLE `nl_novel_chapter98`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_chapter99
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_chapter99`;
CREATE TABLE `nl_novel_chapter99`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nid` bigint(20) NOT NULL COMMENT '小说ID',
  `chapter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '章节名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '小说内容',
  `sort` int(10) UNSIGNED NOT NULL DEFAULT 1 COMMENT '章节排序',
  `add_time` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IndexSort`(`sort`) USING BTREE,
  INDEX `IndexNid`(`nid`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for nl_novel_shelf
-- ----------------------------
DROP TABLE IF EXISTS `nl_novel_shelf`;
CREATE TABLE `nl_novel_shelf`  (
  `uid` int(11) NOT NULL COMMENT '用户id',
  `nid` int(11) NOT NULL COMMENT '小说id',
  `create_time` int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`uid`, `nid`) USING BTREE
) ENGINE = MyISAM CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Fixed;

SET FOREIGN_KEY_CHECKS = 1;
