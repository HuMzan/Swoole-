<?php

$db = new PDO("mysql:host=192.168.0.171; dbname=test_book", "root", "root");
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->exec("set names 'utf8mb4'");

$redis = new Redis();
$redis->connect('192.168.0.146', 6500);
$redis->auth(123456);