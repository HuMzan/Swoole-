<?php
// 在这里引入Composer的自动加载文件
require_once 'vendor/autoload.php';
require_once 'Logic.php';
use QL\QueryList;
$table = new swoole_table(1024);
$table->column('num', swoole_table::TYPE_INT,8);
$table->create();
$table->set("novel_id",['num'=>0]);#小说循环栈



$workerNum = 10;
swoole_process::daemon(true,false);#守护进程开启

$workPool = new Swoole\Process\Pool($workerNum);

$workPool->on("WorkerStart", function ($pool, $workerId)use($table){
    require_once 'DataBase.php';
    $Logic=new  Logic($db);

    $table->incr('novel_id','num',1);
    $num = $table->get('novel_id','num');
    try{ #根据类别，分表，没有就创表
        $reg = array(// 设置采集规则
            "novel_name" => array("meta[property='og:title']","content"),
            "description" => array("meta[property='og:description']","content"),
            "image" => array("meta[property='og:image']","content"),
            "category" => array("meta[property='og:novel:category']","content"),
            "author" => array("meta[property='og:novel:author']","content"),
            "status" => array("meta[property='og:novel:status']","content"),
            "update_time" => array("meta[property='og:novel:update_time']","content"),
        );
        $ql = QueryList::get('https://www.biqugexsw.com/4_'.$num.'/');
        $novelInfo = $ql ->rules($reg)->query()->getData()->all()[0];#小说信息

        $getHtml=preg_replace('/<dt>[\s\S]*<\/dt>/',"",$ql->getHtml());
        $data=QueryList::html($getHtml)->encoding('UTF-8','GBK')->removeHead()->rules([
            'text' => ['dl>dd a','text'],
            'href' => ['dl>dd a','href'],
        ])->query()->getData()->all();#小说目录列表
        $chapterCount = count($data);

        $category = $Logic->checkClass( $novelInfo['category'] );
        if( empty($category) ){#检查是否存在类别，不存在建一个小说分表
            $category = $Logic->setClass( $novelInfo['category'] );
            mkdir(__DIR__.'/Novels/'.$category['cid']);
            $Logic-> setClassNovelTable( $category['cid'] );
        }
        $data['status']=="连载"?$status=1:$status=0;

        //检查小说是否存在，存在更新或跳过；不存在插入；把目录列表链接投入队列爬取
        $novel = $Logic->checkNovelInfo( $category['cid'] , $novelInfo['novel_name'] , $novelInfo['author'] );
        if ( $novel ){#存在
            if( $novel['newest_chapter'] == $chapterCount ){#已经最新
                return true;
            }else{
//                var_dump( $novelInfo['novel_name'].'更新'.$novel['newest_chapter'].' '.$chapterCount);
                for ($a=($novel['newest_chapter']-1);$a<=($chapterCount-1);$a++){
                    $num=$redis->Lpush ("novel_list",swoole_serialize::pack(['info'=>$data[$a],'table'=>$novel['chapter_table'],'nid'=>$novel['nid'],'sort'=>$a]));
                }
                $status!=$novel['state']?$stateSql=",state=".$status:$stateSql=" ";
                $Logic-> updateNovelInfo($category['cid'],$novel['nid'],$chapterCount,time(),$stateSql);

            }
        }else{#不存在
            $nid=$Logic->addNovel($novelInfo['novel_name'],$novelInfo['author'],$novelInfo['description'],$category['cid'],$status,$chapterCount);
            if($nid){
                $chapter_table=$nid%100;#分表
                $url='/Novels/'.$category['cid'].'/'.$nid;
                mkdir(__DIR__.$url);
                $imgUrl=$url.'/'.$nid.'.jpg';
                $Logic->dlfile($novelInfo['image'],__DIR__.$imgUrl);#下载封面图片
                $Logic-> updateNovelTable($category['cid'],$nid,$chapter_table,$imgUrl);#更新小说
                for ($a=0;$a<=($chapterCount-1);$a++){
                    $num=$redis->Lpush ("novel_list",swoole_serialize::pack(['info'=>$data[$a],'table'=>$category['cid'],'nid'=>$nid,'sort'=>($a+1)]));
                }
            }
        }


    }catch(RequestException $e){
        $num = $table->get('novel_id','num');
        if ($num>90200){#已经爬9万本了，出现错误就重置一次，重新爬取
            $table->set("novel_id",['num'=>0]);
        }
    }

    if($num>1000000){
        sleep(1000);#如果有100万队列，休息一会
    }
});

$workPool->on("WorkerStop", function ($pool, $workerId)use ($table) {

});

$workPool->start();







