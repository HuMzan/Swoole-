<?php


class TaskLogic
{

    public $db;

    public function __construct($db)
    {
        $this->db = $db;
    }


    public function addNovelChapter($nid, $chapter_name, $content, $sort, $table)
    {
        $sql = "INSERT into nl_novel_chapter{$table} (nid,chapter_name,content,sort,add_time)VALUES(?,?,?,?,?)";
        $stim = $this->db->prepare($sql);
        $result = $stim->execute(array($nid, $chapter_name, $content, $sort, time()));
        return $result;
    }


    public  function addNovelJsonFile($file_content, $save_to)
    {
        $downloaded_file = fopen($save_to, 'w');
        fwrite($downloaded_file, $file_content);
        fclose($downloaded_file);
    }

}