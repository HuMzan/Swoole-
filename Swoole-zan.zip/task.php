<?php
require_once 'vendor/autoload.php';
require_once 'TaskLogic.php';

use QL\QueryList;
$TaskNum = 10;
swoole_process::daemon(true,false);#守护进程开启
$taskPool = new Swoole\Process\Pool($TaskNum);

$taskPool->on("WorkerStart", function ($pool, $workerId) {
    require_once 'DataBase.php';
    for ($a=0;$a<=300;$a++){#循环n次退出一次
        $list= $redis->rPop('novel_list');
        if (!empty($list)) {
            $TaskLogic=new  TaskLogic($db);
            $list=swoole_serialize::unpack($list);
            $url='https://www.biqugexsw.com'.$list['info']['href'];
            $ql = QueryList::get($url);
            $data=QueryList::html($ql->getHtml())->encoding('UTF-8','GBK')->removeHead()->rules([
                'chapter_name' => ['div.content h1','text'],
                'content' => ['#content','html'],
            ])->query()->getData()->all();#小说目录列表
            if(!empty(stripos('正在手打中，请稍等片刻',$data[0]['content']))){#把没有内容的文章丢到后面队列中
                $redis->Lpush ("novel_list",swoole_serialize::pack($list));
                continue;
            }
            $data[0]['content']=str_replace("请记住本书首发域名：www.biqugexsw.com。笔趣阁小说网手机版阅读网址：m.biqugexsw.com","",$data[0]['content']);
            $data[0]['content']=str_replace($url,"",$data[0]['content']);

//                    var_dump($list['table'].'/'.$list['nid']);
            $save_to='/Novels/'.$list['table'].'/'.$list['nid']."/".$list['sort'].'.json';
            go(function ()use ($data,$save_to,$TaskLogic){#保存内容到json文件
                $TaskLogic->addNovelJsonFile(json_encode(['content'=>$data[0]['content'],'chapter_name'=>$data[0]['chapter_name']]),__DIR__.$save_to);
            });
            go(function ()use ($data,$save_to,$list,$TaskLogic){
                $TaskLogic->addNovelChapter($list['nid'],$data[0]['chapter_name'],$save_to,$list['sort'],$list['table']);
            });
        }
    }

});
$taskPool->on("WorkerStop", function ($pool, $workerId) {});
$taskPool->start();
