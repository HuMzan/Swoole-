<?php


class Logic{

    public $db;
    
    public  function __construct($db)
    {
        $this->db=$db;
    }


    /**
     * @param $cid创建小说所在表
     */
    public function setClassNovelTable($cid){
        $sql="CREATE TABLE `nl_novel{$cid}`  (
  `nid` bigint(20) NOT NULL AUTO_INCREMENT,
  `novel_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '小说名',
  `author` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '作者',
  `introduce` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '介绍',
  `chapter_table` int(5) NOT NULL DEFAULT 0 COMMENT '目录所在表,以nid个，十位分表，分100张',
  `cover_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '封面图片地址',
  `subscribe` int(11) NOT NULL DEFAULT 0 COMMENT '订阅数',
  `click_num` int(11) NOT NULL DEFAULT 0 COMMENT '点击数',
  `pay_num` int(11) NOT NULL DEFAULT 0 COMMENT '畅销数',
  `newest_chapter` int(11) NULL DEFAULT NULL COMMENT '最新章节数',
  `state` tinyint(1) NOT NULL COMMENT '状态，1连载中，0完结',
  `shelve` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否下架，1是，0不是',
  `update_time` int(11) NOT NULL DEFAULT 0 COMMENT '最新更新时间',
  `create_time` int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '后台字段',
  PRIMARY KEY (`nid`) USING BTREE,
  FULLTEXT INDEX `IndexName`(`novel_name`),
  FULLTEXT INDEX `IndexAuthor`(`author`)
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;";
        $this->db->exec($sql);
    }

    /**
     * @param $category
     * @return mixed查询类名是否存在
     */
    public function checkClass($category){
        $sql = "select * from nl_class where class_name=?";
        $stim = $this->db->prepare($sql);
        $stim->execute(array($category));
        $result=$stim->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    /**
     * @param $category
     * @return array|bool插入类名
     */
    public function setClass($category){
        $sql = "INSERT INTO nl_class (class_name)VALUES(?);";
        $stim = $this->db->prepare($sql);
        $result = $stim->execute(array($category));
        return $result?['cid'=>$this->db->lastInsertId(),'class_name'=>$category]:false;
    }

    public function addNovel($novel_name,$author,$introduce,$table,$state,$newest_chapter){
        $sql="INSERT INTO nl_novel{$table}(novel_name,author,introduce,state,newest_chapter,update_time)VALUES(?,?,?,?,?,?)";
        $stim = $this->db->prepare($sql);
        $result = $stim->execute(array($novel_name,$author,$introduce,$state,$newest_chapter,time()));
        return $result?$this->db->lastInsertId():false;
    }


    public function checkNovelInfo($cid,$novel_name,$author){
        $sql = "select * from nl_novel{$cid} where novel_name=? and author=?";
        $stim = $this->db->prepare($sql);
        $stim->execute(array($novel_name,$author));
        $result=$stim->fetch(PDO::FETCH_ASSOC);
        return $result;
    }


    public function updateNovelInfo($cid,$nid,$newest_chapter,$update_time,$stateSql){
        $sql="UPDATE  nl_novel{$cid} set newest_chapter=?,update_time=?{$stateSql} where nid=?";
        $stim = $this->db->prepare($sql);
        $result = $stim->execute(array($newest_chapter,$update_time,$nid));
        return $result;
    }

    public function updateNovelTable($cid,$nid,$table,$cover_url){
        $sql="UPDATE  nl_novel{$cid} set chapter_table=?,cover_url=? where nid=?";
        $stim = $this->db->prepare($sql);
        $result = $stim->execute(array($table,$cover_url,$nid));
        return $result;
    }


    public function dlfile($file_url, $save_to)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_POST, 0);
        curl_setopt($ch,CURLOPT_URL,$file_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $file_content = curl_exec($ch);
        curl_close($ch);
        $downloaded_file = fopen($save_to, 'w');
        fwrite($downloaded_file, $file_content);
        fclose($downloaded_file);
    }
    

}



























