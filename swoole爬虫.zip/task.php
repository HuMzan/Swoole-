<?php
require_once 'vendor/autoload.php';
require_once 'TaskLogic.php';

use QL\QueryList;
$TaskNum = 10;
$taskPool = new Swoole\Process\Pool($TaskNum);

$taskPool->on("WorkerStart", function ($pool, $workerId) {
    require_once 'DataBase.php';
    for ($a=0;$a<=300;$a++){#循环n次退出一次
        $list= $redis->rPop('novel_list');
        if (!empty($list)) {
            $TaskLogic=new  TaskLogic($db);
            $list=swoole_serialize::unpack($list);
            $url='https://www.biqugexsw.com'.$list['info']['href'];
            $ql = QueryList::get($url);
            $data=QueryList::html($ql->getHtml())->encoding('UTF-8','GBK')->removeHead()->rules([
                'chapter_name' => ['div.content h1','text'],
                'content' => ['#content','html'],
            ])->query()->getData()->all();#小说目录列表

            $data[0]['content']=str_replace("请记住本书首发域名：www.biqugexsw.com。笔趣阁小说网手机版阅读网址：m.biqugexsw.com","",$data[0]['content']);
            $data[0]['content']=str_replace($url,"",$data[0]['content']);
            $save_to='/Novels/'.$list['table'].'/'.$list['nid']."/".$list['sort'].'.json';
            go(function ()use ($data,$save_to,$TaskLogic){#保存内容到json文件
                $TaskLogic->addNovelJsonFile(json_encode(['content'=>base64_encode($data[0]['content']),'chapter_name'=>base64_encode($data[0]['chapter_name'])]),__DIR__.$save_to);
            });
            go(function ()use ($data,$save_to,$list,$TaskLogic){
                $TaskLogic->addNovelChapter($list['nid'],$data[0]['chapter_name'],$save_to,$list['sort'],$list['table']);
            });
        }
    }

});
$taskPool->on("WorkerStop", function ($pool, $workerId) {});
$taskPool->start();
